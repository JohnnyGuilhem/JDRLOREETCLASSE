Dans ce bosquet existe un cimetière d'elfes. Suite aux premières bataille en Les Francomtois et les elfes de Dùathalas, les morts elfiques furent entérrer dasn les traditions Francomtoise. 

Quelques siécle après, les Tell'Scoïa vinrent détérer leurs frères tomber désacralisant ainsi le cimetère et attirant la colère de [[Khälrun]], dont le temple trônait au centre du cimetière.