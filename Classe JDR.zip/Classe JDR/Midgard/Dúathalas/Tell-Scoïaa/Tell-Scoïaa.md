Les Tell-Scoïaa sont un mouvement rebelles situés dans le sud de la forêt Dúathalas. Ils s'opposent au joug de plus en plus répressif du Royaume. Suite aux grandes guerres du 2ème au 4ème siècle, les elfes des bois furent obligé de payer un tribut en matière première au Royaume.

Les Tell-Scoïaa attaques les convois et avant poste du royaume dans uen maneuvre de guerilla.