### [[Clerc du chaos]]
Vénérant les dieux du chaos, les clercs du chaos sont versés dans les malédiction et le combat rapproché. Membre des corps expéditionnaires de l’Ordre du dieu à deux têtes du fait de leur connaissance sur les malédiction ainsi que leur talent de guérisseur, ils sont aussi présent sur les champs de bataille en tant que soin de première ligne

### [[Clerc de l’ordre]]
Vénèrant les dieux de l’ordre, les clercs de l’ordre versés dans les arts religieux et de combat. Verser dans les prières et bénédictions de protection et soin, les clercs de l’ordre sont souvent présent dans les hospices et dans les divers lieu de recueillement de l’ordre du dieu à deux têtes.

### [[Paladin du chaos]]
Vénèrant les dieux du chaos, ces paladins en tire des capacités d’embrasement, de poison, malédiction ou encore de maladie. Plus violent que leur frère de l’ordre, ces paladins sont les bras armée des forces inquisitrice de l’ordre du dieu à 2 têtes.

### [[Paladin de l'ordre]]
Vénèrant les dieux de l’ordre, ces paladins ont des capacités de radiant, bénédiction, prière et de rituel. Principaux membre des corps d’exploration religieuse (à coté de leur frère du chaos), ils sont aussi souvent employé comme garde des corps missionnaires de l’ordre du dieux à deux têtes.

### [[Paladin Maudit]]
Le paladin Maudit, ou parjure, est un paladin ayant abandonné son serment au profit pour une raison quelconque. Privé de leur pouvoir et maudits par leurs ancien protecteur, ces paladins sont souvent dangereux et empli de colère.