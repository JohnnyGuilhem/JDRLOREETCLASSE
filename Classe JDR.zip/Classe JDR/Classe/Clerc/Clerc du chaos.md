> Les clercs du chaos vénèrent les dieux du chaos. De part leur connaissances en combat et en religion, ils sont souvent envoyés dans des missions dangereuses d’exploration ou sur les chants de bataille en tant que soignant. Durant ces mission ils travaillent souvent avec leur frère de l’ordre pour le temple du dieu a deux têtes.
---

**Statistiques et équipements de classe**:
Statistique principale : **INT**
Type de dégâts de base : **Physique** et **Radiant**
Équipement de base: 
* Arme à une main(Masse par défaut) D4-2dgt 
* Armure moyenne en cuir: 1RM, 1RP.
* 1 Mélange d’herbes revigorantes: +1PV/tr pdt 3 tr
* Encrier et parchemin
* 

**Pouvoir Divin(Bonus/Competence)**:
Chaque clerc vénère un dieu en particulier. Ce dieu lui prête de sa puissance en lui donnant un bonus et une compétence. Plus le clerc progresse dans son chemin, plus ces compétences s’améliore. 
 - Napalm (Destruction et pillage):  et 
 - Cicéron (Fourberie et tromperie): Avantage au jet de tromperie; Sans visages: le clerc vénérant Cicéron peut recevoir les bonus de sorts d’une autre dieu (Sauf Dundergonde et)
 - Juseä(Justice): et Jugement Divin
 - Schanier(Art): et Inspiration bardique
 - (Chaos):  Puissance du Soleil: Augmente tout les dégâts radiant causé par le clerc et 
 
**Compétence** :
- Lvl1 : 
    Linguiste 1: Apprend une langue parlé communément
- Lvl2 :
- Lvl3 :
- Lvl4 :
- Lvl5 :
- Lvl6 :
- Lvl7 : Spécialisation I

**Magie et religion**: 
- Lvl1 :  
    Malédiction de faiblesse I: -1 jet (atq et sgd) de la cible (INT), 1PF, 1PA
    Détection du bien et du mal: Detecte l’alignement de la cible 1PF
    Lumière divine: Éclaire une pièce, 1PF
- Lvl2 : 
    Restauration Mineur I: +2 PV temporaire, 1PF
    Purification Mineure I: Soigne les altérations temporaires,  1PF
- Lvl3 :
    Coup Divin I: 1D4 dgt Radiant, 2PF
    Soit:
     - Influx Divin I:  Restaure D2 Pv/tour, 1PF/tr lancement
     Ou
     - Bouclier de foi I: Donne +1RC à cible et résistance au dgt Radiant 
- Lvl4 :
    Sanctuaire I: Empêche les ennemis d’attaquer la cible du sort tant qu’elle n’attaque pas
    Protection contre le mal I: Fait fuir tout démon, maudit, mort vivant, diable de niveau inférieur au lanceur, 2PF
    Arme bénie I:  Enchante 1 arme: 1d2 radiant
- Lvl5 :

#### **Spécialisation**:
