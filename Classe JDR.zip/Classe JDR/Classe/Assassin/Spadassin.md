> Le spadassin est un mercenaire. Il accepte des contrat et les exécute, souvent dans le silence. La différence majeur le spadassin et un mercenaire est que le spadassin travail souvent seul et pour son propre compte. Sans affiliation ni politique ni religieuse, les spadassins ont peu d’amis, bien que beaucoup de riches seigneurs et marchands tente de s’offrir leur service comme garde du corps.



**Compétence** :
- Lvl1 : 
- Lvl2 :
- Lvl3 :
- Lvl4 :
- Lvl5 :
- Lvl6 :
- Lvl7 : Spécialisation I