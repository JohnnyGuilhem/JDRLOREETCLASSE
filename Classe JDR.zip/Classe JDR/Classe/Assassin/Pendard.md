> Le pendard est un assassin spécialisé dans le contrôle et l’entrave. Bien qu’il soit furtif, ses points commun avec le spadassin s’arrête là. Le pendard pose des pièges pour neutraliser ses proies. On les appelles pendard car l’on raconte que lorsqu’ils piègent quelqu’un, il est comme le pendu la corde passée au cou: "Il n’y a pas d’autre issue que la mort".
---


**Compétence** :
- Lvl1 :
	+1 Maitrise DEX
	+1 Dgt cdt caché 
- Lvl2 :
    Écran de fumée : Permet de lancer des petites billes dans un rayon de 2m  autour du lanceur. Ces billes produisent une léger écran de fumée donnant avantage au jet de DEX de 2m/2m, 2tr. 1/Combat
    Recette d’alchimie : Fumigène : Huile, herbe humide, amadou séché.; Effet: crée un écran de fumée 3m/3m, donne avantage dex et désavantage JDS
- Lvl3 :
    Pied léger : Ne fait plus de bruit lors de déplacement furtif
    Coup dans le dos: CC cdt caché càc
- Lvl4 :
	Roulade furtive: 1 PU, cdt caché, D4m, ne genere pas de réactions 
    - Crochetage: Crocheter des serrures faciles
     **ou** 
    - Vol à la tire: D100 escamotage(tout les 20 nouvelle couches)
- Lvl5 : Spécialisation I
	
- Lvl6 :
	
- Lvl7 :

**Spécialisation**:
