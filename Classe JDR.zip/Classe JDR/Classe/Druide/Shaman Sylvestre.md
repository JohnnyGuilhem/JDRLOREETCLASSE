> Versés dans les arts de métamorphose et de communication animal. Ils font souvent appel aux esprits d’animaux afin d’utiliser certaines de leur force.
---

##### Statistiques et équipements de classe:
Statistique principale : **STR**
Type de dégâts: **Physique**
Équipement de base: 
- Gourdin
- Manteau à capuche
- Herbes médicinales: +1PV/TR pdt 2tr

**Compétence**:
- Lvl1:
    -Sang Bestial I:
        - Loquere animalibus I : Permet de communiquer avec des très petits animaux
        - Animaï : Infuse d’une âme animal (1cible)
            - Loup: +1Dgt jets
            - Ours : -1 Dgt subis
            - Aigle : +1 Dgt jets allié ou -1 Dgt subis allié
- Lvl2:
    +1 Maitrise nature
- Lvl3:
    - Sang Bestial II :
		- MRS (+0,5); +1Dgt;
		- Loquere animalibus II : Communique avec les petits animaux
		- Animai: 
		    Loup: Coup double: attq 2* avec -1dgt
		    Ours: Taunt: attire et inflige peur d20>lvl
			Aigle: Cri des cieux: Donne bonus tout alliés D20>WIS
- Lvl4:

**Magie et religion:**
- Lvl1: 
    - Transformation en très petits animaux:
        -(0~1)dgts d’attaque, v (sol et air) = 10m/s, 1PV.
        - Transformation en rat, moineau, écureuil 
- Lvl2: 
    - Transformation en petits animaux:
        -Renard, Brochet, Faucon:
	    -D4 dgt; v (sol et air) = 10m/s; 6PV
- Lvl3:
	