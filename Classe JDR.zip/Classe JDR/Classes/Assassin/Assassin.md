	lvl 1:
		- Guerrier des ombres: 
			- AV sur les jets de sauvegarde en discretion 
	lvl 2:
		- + 1 Maitrise Discretion
		 - Coup dans le dos I: AV sur attq discrète
	lvl 3:
		-point faible I: Si il a déja combattu cette énnemi, il lui fait +1dgt
	lvl 4:
		-