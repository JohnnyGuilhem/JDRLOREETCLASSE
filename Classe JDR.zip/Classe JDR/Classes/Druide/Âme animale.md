	lvl 1:
		- Transformation en petits animaux innofensif:
			 - (0~1)dgts d'attaque, v (sol et air) = 10m/s, 1PV.
			 - Transformation en rat, moineau, écureuil
		- Sang Bestial I :
			- Loquere animalibus I : Permet de communiquer avec des très petits animaux
			- Animai: Infuse d'une âme animal:
				- Loup: +1Dgt
				- Ours: -1Dgt
				- Aigle: +1Dgt allié, -1Dgt ennemi
	lvl 2:
		- Sang Bestial II :
			- MRS (+0,5); +1Dgt;
			- Loquere animalibus II : Communique avec les petits animaux
			- Animai: 
				- Loup: Coup double: attq 2* avec -1dgt
				- Ours: Taunt: attire et inflige peur d20>lvl
				- Aigle: Cri des cieux: Donne bonus tout alliés D20>WIS
	lvl 3: 
		- +1 Maitrise Nature
		- Transformation en petits animaux:
			- Renard, Brochet, Faucon:
				-D4 dgt; v (sol et air) = 10m/s; 6PV
	lvl 4:
		-