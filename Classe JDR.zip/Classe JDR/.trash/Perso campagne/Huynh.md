Kiklain -- Druide viens du nord de Mossley
Physique -- Ressemble fort à une poule du à ses malheuuurs passé.Physique chngeant en fonction decertaine condition.
Caractéristiques:A peur de l'orange, végan, mange des graines placebo
Capacités: Pond des oeufs magiques, sort d'hypnose?, en transofrmaton premier tour pile ou face et s pile effet aléatoire.