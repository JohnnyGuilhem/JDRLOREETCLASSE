Toutes entités du JDR possède une fiche personnage. Cette fiche détail ses statistiques, majeur et mineur, son lore, son nombre de PV, PF, de point de folie, son équipement, son niveau, ses compétences et sorts, et tout autre info pouvant être utile dans quelconque situation du JDR.

### Création de la fiche de personnage

### Système de Niveau

### Point de vie, de magie et de folie :
##### Point de vie:
Chaque chose du monde du JDR possède un certain nombre de points de vie. De la barique de vin au château ou du rat au dragon, rien n’échappe à cette règle même si certains jouent avec. 

Le nombre de points de vie maximum est calculé avec la constitution et le MRS(modificateur racial de sang):
    **CON * MRS = PV**
Ce chiffre évoluera en gagnant des niveaux ou certains bonus/attribut au fur et à mesure de l’aventure.

