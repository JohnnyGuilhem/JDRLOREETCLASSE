### Déroulement :
Tout combat se déroule en 3 phase. La première, l’initiative, la deuxième, les tours de combats et la troisièmes, la résolution. 

**L’initiative** est la phase qui reprend tout ce qui se passe avant le premier tour de combat. Cette phase regroupe: les jets d’initiative, l’analyse des statut, les bonus de circonstances ainsi que la surprise.

**Les tours de combat** regroupe tout les tours du déroulement du combat, du premier tour jusqu’à ce que le dernier ennemi soit mort malgré tout les efforts du MJ.

**La résolution** reprend l’XP, le loot, et les circonstances post-combat.

 ---

### Initiative

#### ​Jet d’initiative 
Le Jet d’initiative est la premier chose demander par le maître du jeux en combat et d’ailleurs peut servir d’indicatif au joueur qu’un combat se lance.

Au début du combat, tout les participants lance 1d20 et y ajoute leur statistique d’initiative. Le plus haut résultat sera le premier à jouer et le plus bas résultat sera le dernier. Les succès critique et échec critique sont, dans l’ordre, les scores maximal et minimal.

Certaines circonstances peuvent faire varier ou fixer les positions d’initiative ainsi qu’accorder des bonus au jet d’initiative. Ces circonstances sont entièrement dépendante du MJ. 

Certaines pieces d’équipements peuvent aussi accorder un bonus d’initiative. 

`Note: L’effet de surprise ne modifie pas les résultats des jets d’initiative`

#### Analyse des Statuts:
Une fois l’ordre de combat déterminé, chaque protagoniste regarde ses statistiques et statut, révélant au MJ et ses partenaires tout info pouvant avoir une influence sur le combat. Tout manquement volontaire peut évidemment avoir des conséquences définies par le MJ.

#### Bonus de Circonstances:
Les bonus de circonstances sont tout les bonus et malus que l’environnement ou les circonstances pré-combat peuvent donner aux protagonistes du dit combat. Ces bonus et malus sont définis par le MJ.

#### Suprise:
Dans certaines circonstances, une partie des protagoniste du combat peuvent prendre par surprise l’autre partie. Le combat commence normalement avec les jets d’initiative pour déterminer l’ordre. Lorsque le premier tour de combat commence, les protagonistes "surpris" passe leur tour. Ils pourront ainsi jouer qu’à partir du deuxième tour.

---

### Tour de combat
Au début du tour d’un protagoniste, il doit d’abord regardé aux bonus et malus qu’il subit. Ensuite, il peut bouger, attaquer/lancer un sort ou utiliser une compétence et utiliser un consommable.

`Note: certaines compétences ou sort permettent d’utiliser plusieurs competence`

#### Mouvements:
Tout chose dans l’univers du MJ possède une vitesse(1ère loi de Èmji). Cette vitesse peut être aussi bien nul que infinie, au bon vouloir du MJ. 

Durant son tour de combat, le protagoniste dont c’est le tour peut bouger d’un certain nombre de case plus ou moins bonus/malus. Il peut bouger quand il le souhaite, au risque de devoir se désengager.

Il est possible de faire varier les distances parcourue par un protagoniste en le faisant:
- ***Sauter***: utilise une partie de ses points de mouvements équivalents à la distance sautée. Par mètre sauté horizontalement, il faut doubler le nombre de points de mouvements nécessaires.
- ***Sprinter***: (voir utilitaire)
#### Désangagement et Réaction:
##### Réaction :
Certains sort et mouvements peuvent générer une opportunité de réaction. Chaque joueur à droit à une réaction par tour et peut l’utiliser en dehors de son propre tour. Une réaction peut être provoquer par 1: un désengagement, ou 2: un sort. 

- ###### Désengagement  :
  Lorsque un protagoniste souhaite bouger hors de porté d’un opposants n’ayant pas encore utilisé sa réaction, l’opposant peut l’attaquer et le protagoniste dont c’est le tour se défend avec désavantage. 

- ###### Sort:
  Certain sort peuvent permettre une réaction, soit en étant contré par le sort: *Contresort*; soit activant un passif. Ces passifs peuvent avoir plusieurs effets qui seront tous détaillé lorsqu’il sont acquis.
 
#### ​Compétence, Attaque et Utilitaire:
Chaque tour, chaque protagoniste a, à son tour, une action et un utilitaire.
##### Compétence et consommables :
Les compétences et consommables  se divisent en deux catégories,  les utilitaires et les actions. Elles peuvent s’utiliser tout au long du tour du protagoniste et parfois même en dehors du tour.
##### Action :
Sont considérés comme action: les attaques (Physique ou Magique), certains consommables avec le mot clé action et certaines compétences avec le mot clé action. L’action peut être utilisé à n’importe quel moment du tour du protagoniste. Certaines compétences, sort ou encore bonus peuvent augmenter le nombre d’action par tour.
###### Attaque:
L’attaque se déroule en 3 phase: le jet d’attaque, celui de sauvegarde, et en cas de réussite de l’attaque, le jet de dégât. Elle consomme un point d’action.

* ***Jet d’attaque***: Il se calcule en lançant 1D20 et en y ajoutant la statistique utilisée pour attaquer ainsi que les bonus d’équipement de sort. Cette statistique est définie par l’arme ou le sort employé. En cas de réussite critique (20 au lancé), l’attaque inflige le double des dégâts. Dans le cas d’un échec critique, l’opposant peut attaqué en retour et saute le jet de sauvegarde. Certains résultats peuvent être modifié et le critique annulé dans certaines circonstances définies par le MJ ou grâce à certaines aptitudes.

  Ex: Si je fais 14 au dé et que j’attaque avec 15 de force, mon jet d’attaque est de 29. (14 + STR = 29)

* ***Jet de sauvegarde***: Il se calcule en divisant la statistique utilisée pour esquiver par 2 (équipement compris) et en y ajoutant 1D20, les bonus de sorts*, et le RP ou RM efficace(qui n’est pas ignoré par le type de l’attaque). En cas de réussite critique, l’attaque échoue automatiquement et le défenseur peut utiliser une réaction pour attaquer en sautant le jet de sauvegarde.

  `*: Certains sort augmente les résultats des jets de sauvegardes, d’autre une statistiques spécifiques. Faire attention à ne pas confondre durant le calcul.`

Si le jet d’attaque est supérieur au jet de sauvegarde, l’attaque touche automatiquement et on lance les dés de dégâts, sinon elle échoue et s’arrête.

* *Jet de Dégât* : En fonction du type d’équipement ou sort utiliser pour infliger des dégâts, un certain nombre et type de dé seront requis. Leur total inflige le nombre de dégâts et ce parfois par type avec plusieurs sous totaux.

Dans le cas ou l’un des protagoniste voit ses PV tomber à 0, voir page [[Fiche de personnage et classe]]

`Note: Si les deux parts font une réussite critique à leur jets. L’attaque est annulée et personne ne prend de dégats supplémentaires. `
##### Utilitaire :
Sont considérés comme utilitaire: certaines compétences comprenant le mot clé utilitaire, certains consommables avec le mot clé utilitaire et la liste suivante(bien qu’il ne consomme pas tous un point d’utilitaire):

- *Sprint*: sacrifie un point d’action pour doubler la vitesse de course
- *Désangagement*: sacrifie un point d’utilitaire pour se désengager sans déclencher de réaction.
- *Tacle*: D20 STR (sans armes ou avec arme STR*) ou D20 DEX (Si Arme), sur une réussite diminue de moitié la vitesse de la cible, sur réussite critique fait tomber la cible en plus, lui donnant désavantage à ses jets. Consomme un point d’action.
- *Ramasser*: Utilise une point d’utilitaire pour Ramasser un objet au sol.
- *Lancer*: Sacrifie un point d’action pour lancer un objet à une distance 1d20 + force.
- *Se cacher*: Utilise une point d’utilitaire pour se cacher. Lance un D20 en **DEX**, tout les opposants qui ont la personne cachée dans le champs de vision lance 1D20 avec perception. Chaque fois que l’utilisateur entre ou sort d’un champ de vision, les opposants concernés relance 1D20 perception et l’utilisateur relance 1D20 **DEX**.

 `*: Certaine classes de héros utilise la WIS comme attribut de force` 

---
### Résolution :
Une fois le combat fini, chaque personnage reçois son XP et gagnes ses niveaux, selon l’usage du MJ. Voir aussi la rubrique "[[fiche personnage et statistique]]"

Ensuite, ils peuvent looter les lieux du combats. Aux joueurs de définir la manière et l’ordre dans lesquels il se répartisse leur trésors.