## Résistance Magique (RM), Physique (RP) et à effet

### Résistance Magique (RM):
La Résistance Magique ou RM en abrégé, est la résistance à tout type de dégâts magiques*. Toute créature possède une RM, calculée avec sa statistiques d’intelligence, ses bonus de races et classe ainsi que son équipement.
La formule de calcul est la suivante:

**(INT/2) + Équipement + ou * Bonus = RM

``*Les dégâts radiant et dégâts de sorts tel que embrasement ou empoisonnement ne sont pas considérés comme magique. Seul les dégâts de sorts magiques direct utilisé la RM

`Note: ces statistiques ne sont pas fixe et varie au fur et à mesure de l’aventure.

---
### Résistance Physique (RP)
La Résistance physique regroupe trois type de dégâts: les dégâts contondants, tranchant et perforant(pour plus d’info consulte la rubrique lexique). La RP se calculé de la même manière que la RM, sauf que la constitution est l’attribut majeur repris dans le calcul

**(CON/2) + Équipement + ou  * Bonus = RP

`Note: ces statistiques ne sont pas fixe et varie au fur et à mesure de l’aventure.

---
### Résistance à effet
Certains équipements, races ou encore monstres peuvent avoir des Résistance à des types de dégâts spécifiques.

-ex: Résistance au dégâts Perforants ou encore Résistance au dégâts de feu.

Ces résistances se divisent en 2 catégories:

1. Résistance Global: La Résistance Globale diminue les dégâts subis d’un pourcentage. Résistance I retire 25%, Résistance II, 50%, Résistance III, 75% et finalement immunité qui diminue donc de 100% les dégâts subis.
 
   -ex: Si je subis 4dgt de feu et que j’ai ==Résistance I== au dégâts de feu, alors je prend 3 dgt de feu. (4 -(4 * ==1/4==) = 3)

2. Absorption: La Résistance à palier ou absorption protège d’un nombre de dégâts fixe. Passé ce nombre, tout les dégats supplémentaires sont subis.

   -ex: Si je subis 4 dgt de feu, et que j’ai une ==Absorption du feu de 3dgt==, je subis 1 dgt. (4 - ==3== = 1)

`Note: Certaines créatures peuvent avoir des Résistance de tout type naturellement(dont les immunités) 

---