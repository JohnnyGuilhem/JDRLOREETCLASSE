---
cssclasses:
  - Quête
---
Disponible près de [[Hastan Piedferme]] à la [[Caserne des Mercenaire-Prisonnier]]

Dans une maison du quartier Luméciel, une jeune femme et une vieille sont endormie.

Un mage ou oniromancien, viens pour plonger la team dans le rêve. Il revive la vie de la femme et la fille, les moments marquant.

1.Le massacre du village:
	La team arrive dans la peau de brigands. Ils sont envahi d'une envie de meurtre et attaque les villageois. La clé pour sortir est touché la femme ou son enfant (en fonction de quel rêve ils ont choisi).
2.La rivière:
	La team est transformé en animaux. La femme et son enfant sont au bord de la rivière. Au loin le bruit d'un chien et d'un homme (deux incarné de la team qui chasse la femme).
	Si il bute la femme et la fille, cauchemar aka casse tête:
		La rivière rest normal, un écoulement s'entend. la forêt est en feu, impossible d'en sortir(boucle temporelle). Deux choix pour sortit, 1 comprendre que c'est un cauchemar et se buter, 2 méditer et comprendre que c'est un cauchemar.
	Sinon il suffit de remonter la riviere ou sortir du bois. à ce moment là il faudra retrouver un jouet pour enfant (poupée). De la poupée ressort deux ombres(4Pv, tp, 1d2 dgt mentale (fois pt folie)), la team  (4Pv, 1d2 dgt)
3.L'assascion

	Si mamy: Trouve la mamy en train de draguer un noble. Ils sont dans une salle de banquet. La team reprend des aparencees humaines/nobles. Un moment il s'éclipse par une porte. Si il ne le remarque pas, ils doivent chercher. Les deux nobles sont dans une chambres, ils sont sur le point de baiser. Si ils les laissent baiser, ils debloquent le boss rêve sinon le boss cauchemar.

	Si fille: Ils sont dans un labyrinthe, il fait sombre. Ils ont un temps pour sortir du labirynthe. Si ils sorte a temps, boss rêve, si ils ne sorte pas a temps, découvre la fille et un noble pecho salle centrale. Boss cauchemar 

4.BOSS
	UN célicole.
		Boss sympa, il doivent affronter leur double

		Boss pas sympa, ils doivent affronter leur pire cauchemar


