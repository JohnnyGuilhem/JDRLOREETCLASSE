Disponible près de [[Hastan Piedferme]] à la [[Caserne des Mercenaire-Prisonnier]]


Inspection d'une maison de mage suite à des bruits bizarre entendu la nuit

Rencontre du Mage:
	Absent et maison sacagée
	SI ils arrivent de nuit, bruit bizarre ambiance glauque
	 Sinon mauvaise odeur (cadavre en decopmposition)
Sinon rien d'interessant. Si ils investiguent ( plein de manière) Bibliothèque qui s'ouvre sur un escalier.
En bas le corps en pourriture avec un visage auxquels on aurait aspirer la vie
 Si ils inverstiguent  decouvre une sorte de tombe pas loin parmi divers élément alchimique.
 Si ils ouvrent trouves un cadavre et bam ils petent son crane et c'est magnifique 
Ame de con j'ai oublie le nom

reward:  150 pièce de bronze
	  Bague de magie : +1PF
	  Bague de puissance : +1 effet sort
	  Bibelots vendable 15 piece
	  Collier de mage +1PF