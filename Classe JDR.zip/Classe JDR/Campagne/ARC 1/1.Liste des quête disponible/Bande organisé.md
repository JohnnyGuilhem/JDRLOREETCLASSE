---
cssclasses:
  - Quête
---
Disponible près de [[Hastan Piedferme]] à la [[Caserne des Mercenaire-Prisonnier]]

Objectif entré dans un repère et buté tout le monde

20 truands 
Stuff lootable:
armure de cuire (légère) (1RC)
Arme  en bronze (d4-1)
5-10pièce

si grosse luck 5~6

anneau d'attribut majeur
anneau d'attribut secondaire