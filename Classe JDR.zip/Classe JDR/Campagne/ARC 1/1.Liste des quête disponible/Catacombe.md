Disponible près de [[Hastan Piedferme]] à la [[Caserne des Mercenaire-Prisonnier]]

Les morts se lève 
10 squelette 
unnécroman tarpin faible s'exerce dans les catacombes
buter optionnel

Qq pièce, la robe du nécroman +1 jds INT, un livre sur les arcanes. personne peput comprendre sauf le nain.