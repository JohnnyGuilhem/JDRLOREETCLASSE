 Disponible près de [[Hastan Piedferme]] à la [[Caserne des Mercenaire-Prisonnier]]
La note dit: 
Venez me voir après le soleil couché dans la cour centrale.

Il rencontre Hastan Piedferme assis contre un pilier. Il leur fait un geste de main et les invites à le suivre. Il entre dans une cave, ferme la porte a clé et s'assied a la table. La il leur donne son nom et leur demande de s'asseoir. Il énonce leur fiat malicieux et leur propose du travail un peu plus sombre.

Aller fouiller des caisses de marchand:

Des marchand suspect mais parfaitement en règle ont échappé à la fouille de leur marchandise grace à un sceau marchand. Cela dit il semble que le sceau soit factice, helas aucune preuve ne permet de contredire la validité. Le groupe transportant la marchandise s'appelle La companie des Îles orientales et la cargaison viendrais du royaume des Îles et trnasporterais des fourrures et metaux précieux.

Ils doivent aller fouiller le hangar ou sont stocké les marchandises. Petit hangar avec 3 gardes à l'entrée (10pv, 20STR, D4-1 dgt (bludge)) et deux à l'arrière. 2 garde circule à l'intérieur. Sur le coté, quelque planche semble pourris sur le coté. Sinon à l'arriere un sorte de baie vitrée aux verres fumé à l'étage donnant sur le fleuve. Une fenêtre au milieux supérieur d'un des murs est apparante et à un volet entre ouvert.
Si tante de buté boss, et réussi reçois full thunas un petite arbalete faisant D4-1 dgt et silencieuse, une dague faisant D4-2 et inflige poison, un livre sur les religion ancienne (+1 effet sort), Bague de force +1 str, Cape +1Cha.
SI perd, ils sont capturé et torturé dans une cave. Game Over. à l'intérieur, du coté entrée des grands echafaudage sur lesquels des marchandises sont empilées. dans un coin, 2 Garde joue au carte. Au fond un escalier en pierre qui debouche sur une porte, un garde en haut de l'escalier. Derrière la porte un somptueux bureaux avec deux mafieux dedans (15PV et 20PV,20 str, 3AC,, d4 dgt perceant pr un et bludge pr autre). sous l'escalier trappe. 

LA trappe donne sur une sorte de ponton donnant sur un bateau charger de marchandises. Il est possible de passer au travers du mur qui est fait d'une illusion. Une caisse contient des épées en fer (D6-2), un tonneau rempli de flêche, (3flêche percente, 2 fleche assomante). Finalement quelque caisse sont remplies, sous desétoffes, de sac rempli de cristaux. C'est une sorte de drogue. Seul le hobbit peut savoir avec une jet en investigation. Dans une dernière caisse, ce trouve une enorme boite. Cette boite, une sorte de dispositif magique encastré dans une boite en verre sele un amulette. Il s'agit de [[L'amulette de Gauldur]].

Le roi cherche cette artefact de légende.

Gagne des mois et de la thune.

Extortion d'info

Torture d'un type pour lui chopper des infos confidentiel. Il s'agit d'une elfe des bois qui organise la révolution contre la tyrannie du roi actuel. La torture ou la pesuasion peuvent fonctionner. L'hommee est une elfe des bois. il fait partie d'une organisation rebelle appelé les [[Tell-Scoïaa]]. Il s'appelle [[Elowen]], et est un messager de confiance. Il peut leur proposer un plan pour qu'il s'échappe. Son plan est de fuir par les égouts. Il faut que les aventurier trouve le moyen de le laisser partir. Sinon, il à des infos sur le roi, qui cherche un artefact spécial. De plus il connait l'emplacement d'un camp [[Tell-Scoïaa]].

La prison est au sous sol, et au centre un puits à été installé. Ce puit sert a vidé les excréments des détenus. Cet endroit amène aux égouts. Ils peuvent tenter de s'orienter hors de la ville. Plusieurs problème se révèle. Si ils suivent le cour de l'eau ils arrivent dans une énormes fosses ou l'eau semble couler indéfiniment. Il y a un tourbillon au centre du puits. Tout les x temps, l'eau est expulsé d'un coup dans un trou a coté du tourbillon. L'eau est filtré et ressort dans le canal propre. Lore [[Bregða Vatn]]
