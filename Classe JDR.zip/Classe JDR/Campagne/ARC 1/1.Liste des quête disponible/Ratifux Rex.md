Disponible près de [[Hastan Piedferme]] à la [[Caserne des Mercenaire-Prisonnier]]

