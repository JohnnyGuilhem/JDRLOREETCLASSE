	Si ils libèrent Elowen, ils doivent se rendre jusqu'à la forêt. Soit il coupe à travers champs pour limiter les rencontres humaines, soit il continue sur la route au risque de se faire chopper.

Premier choix plus dangereux:

Dans le cas ou ils suivent les revolutionaires ils arrivent dans la forêt les yeux bandés jusqu'a un campement rebelle dans la fôret.

La ils sont amené devant un homme, un khajiit, homme chat venu du nord, du Nom de [[Ra'khargii]]. Ancien Capitaine, ils fut demis de ses fonction après les nouvelles mesures du roi. Suite à ca, il parti rejoindre la rebellion [[Tell-Scoïaa]]. 

La le sergeant leur demandera de prouver leur loyauté. Ils leur donne une liste de 5 noms: [[Harry Kasaar]], [[Nefer le Pieux]], [[Hastan Piedferme]], [[Vadin Tazägd]] et finalement [[Varin De Beauciel]] et leur demande de les rejoindre