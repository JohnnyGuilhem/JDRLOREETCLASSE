**CC ou Coup critique**: Augmente les dégâts de 100%(taux peut varier en fonction des classes)
**Càc ou Corps à corps**: Concerne toute attaque à moins de 2m de portée de l’utilisateur moyen(peut être sujet à des exceptions )
**Cdt ou Condition**: Liste de ce qui doit être rempli pour activer un effet
**Inmmunisé**: Diminue de 100% les dégâts subis du type concerné 
**Résistance**: Diminue de moitié les dégâts subis du type concerné 
**Dégât:** Tout type de dommage pouvant potentiellement blesser une créature ou objet.
**Dégât physique:**  
	- *Contondants* : dégâts de choc ou d’impact. Dégât type des masses d’armes.
	- *Perforant:* dégats ciblé, ignirant parfois la RP. Dégat typede certaine lance et de certains arcs
	- *Tranchant*: dégâts de tranchant, infligeant des coupures et parfois le saignement. Dégât typique des épées, hachés et tout armes à bord tranchant