Situé au nord est de Mossley, le Bosquet de Khyne est l'un des derniers vestige de grande forêt de Dúathalas. Peu de gens ose s'approcher du Bosquet car, en son centre, fut érigé un cimetière qui bien que rempli d'elfe, fut bati par des hommes pour y entérré les officiers elfes tués au combat. La légende raconte que ce cimetière est hanté et qu'il y règne de sombre créatures.

Le bosquet pris son nom après une divinité mineur, [[Khyne]]
