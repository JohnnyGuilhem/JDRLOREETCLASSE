Un grand batiment avec une cour ouverte au centre. Le batiment est divisible en 4 partie, deux ailes de prisonniers, un aile cantine et une aile artisanat avec [[Hastan Piedferme]], [[Nakrim le Forgeron]], [[Otto l'intendant]] et [[Marte l'instructrice]].

