
Capitale du Royaume