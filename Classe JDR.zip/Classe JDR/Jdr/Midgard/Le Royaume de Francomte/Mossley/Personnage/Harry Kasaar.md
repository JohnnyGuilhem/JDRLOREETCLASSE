Harry Kasaar est un forgeron de Mossley. Bien qu'il descende d'une lignée de forgeron  de renom, il n'a hérité des talents familiaux. 

Il est actuellement employé par la garde et est le forgeron principale de l'armée, fabriquant tout pièce basique d'armement. Pour compenser ses manquements artisitiques, il s'établit comme un irremplasable de la chaine d'approvisionnement, de tel manière à être indispensable.

Cela dit il à des accords avec [[Le Siège Dandessous]], détournant du matériel contre des pots de vins.