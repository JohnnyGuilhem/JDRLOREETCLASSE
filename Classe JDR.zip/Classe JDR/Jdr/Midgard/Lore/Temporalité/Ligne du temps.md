Aux dernières modification de cette note, l'an était 1468 du calendrier commercial*, presque un an apès la dernière guerre des elfes de cette ère.

Tout d'abord, il existe plusieurs version du calendrier emploié actuellement par les compagnies commercial:
	Les hommes emploies le Calendrier d'Anfroi, en référence à [[Anfroi le Libérateur]], qui eu une place majeur dans la libération des peuplades hommes de la domination elfique du monde connu. ce calendrier divise la periode de temps entre l'âge sombre (avant l'an 0) et l'Âge d'or (après l'an 0)
	Les nains quant à eux ont une ligne de temps qui n'est pas divisé en âge car,  bien que les royaumes nains modernes possède un Haut-roi, ce rôle n'est en réalité que très récent et leur unité est récente.
	