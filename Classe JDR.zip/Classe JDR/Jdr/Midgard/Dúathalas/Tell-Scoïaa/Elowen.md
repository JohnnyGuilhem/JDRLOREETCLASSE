Jeune Elfe qui se bat dans la résistance. Son père est un marchand exploité. Ils vivent frugalement et sa mère est malade d'un mal étrange. Peut devenir un pote du grp.

Archer 10 PV 

