Hästi est l'une des dernières géante qui a parcouru ce monde.

Elle fit 10 enfants au dieu forgeron Nünsi. Le dernier, [[Andvari]], tua sa mère à l'accouchement, lui étripant les entrailles.

Voici ses enfants par ordre de naissances:

[[Mótsognir]] dit l'ainé
[[Brokk et Eitri]] dit les jumeaux forgerons
[[Ivaldi]] dit L'artisan
[[Fàfnir]] dit Le Protecteur
[[Nordri, Sudri, Austri et Westri]] dit Les Porteurs du Ciel
[[Andvari]] dit Le mauvais
