Dieu de la révolte et du tribal

Père de [[Nünsi]]