Déesse du foyer et de la vieillesse

Mère de [[Elsifëa]]