Mótsognir, le premier des nains, est conté comme étant le plus sage de la portée. La légende va même jusqu'à raconter que certaines lignées de Hauts Roi Nains sont des déscendant direct Mótsognir. Seul [[Fàfnir]] aurait aussi comme descendance des Lignées de Hauts roi.

Mótsognir serait aussi celui, qui par son ingéniosité, pièga son petit frère Ivaldi pour le bannir sur un autre plan d'existance.