Déesse des arts

Mère de [[Nünsi]], de [[Dyméterion]] et [[Dyméterie]]