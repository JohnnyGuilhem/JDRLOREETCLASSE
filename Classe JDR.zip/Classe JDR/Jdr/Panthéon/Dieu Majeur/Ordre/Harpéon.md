Harpéon dieu de la sagesse

Père de [[Elsifëa]]