---
aliases:
  - Ordre
cssclasses:
  - Dieu
  - Majeur
---
Melhiug dieu ordre