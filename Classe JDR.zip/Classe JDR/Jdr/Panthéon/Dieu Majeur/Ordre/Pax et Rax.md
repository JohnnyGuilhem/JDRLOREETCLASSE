Dieu de la paix et de la guerre

Père de [[Hastéa]]

Dieu a 2 têtes