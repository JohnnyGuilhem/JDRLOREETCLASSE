> Vénèrant les dieux de l’ordre, les clercs de l’ordres sont versés dans les arts religieux et de combat. Verser dans les prières et bénédictions de protection et soin, les clercs de l’ordre sont souvent présent dans les hospices et dans les divers lieu de recueillement du temple du dieu à deux têtes.
---

##### Statistiques et équipements de classe:
Statistique principale : **INT**
Type de dégâts de base : **Physique** et **Radiant**
Équipement de base: 
* Arme à une main(Masse par défaut) D4-2dgt 
* Armure moyenne en cuir: 1RM, 1RP.
* 1 Mélange d’herbes revigorantes: +1PV/tr pdt 3 tr
* Encrier et parchemin
* 

**Pouvoir Divin(Bonus/Competence)**:
 - Hapéon (Sagesse):  et 
 - Pax et Rax(Paix et Guerre): Boost dgt soin et 
 - Juseä(Justice): et Jugement Divin
 - Schanier(Art): et Inspiration bardique
 - Dundergonde(Ordre):  Puissance du Soleil: Augmente tout les dégâts radiant causé par le clerc et 
**Compétence** :
- Lvl1 : 
    Linguiste 1: Apprend une langue parlé communément
- Lvl2 :
- Lvl3 :
- Lvl4 :
- Lvl5 :
- Lvl6 :
- Lvl7 : Spécialisation I

**Magie et religion**: 
- Lvl1 :  
    Bénédiction I: +1 jet (atq et sgd) d’un perso, 1PF
    Détection du bien et du mal: Detecte l’alignement de la cible 1PF
    Lumière divine: Éclaire une pièce, 1PF
- Lvl2 : 
    Soin Mineur I: +1d2 PV, 1PF
    Restauration Mineure I: Soigne les altérations temporaires 
- Lvl3 :
    Coup Divin I: 1D4 dgt Radiant, 2PF
    Soit:
     - Influx Divin I:  Restaure D2 Pv/tour, 1PF/tr lancement
     Ou
     - Bouclier de foi I: Donne +1RC à cible et résistance au dgt Radiant 
- Lvl4 :
    Sanctuaire I: Empêche les ennemis d’attaquer la cible du sort tant qu’elle n’attaque pas
    Protection contre le mal I: Fait fuir tout démon, maudit, mort vivant, diable de niveau inférieur au lanceur, 2PF
    Arme bénie I:  Enchante 1 arme: 1d2 radiant
- Lvl5 :

#### **Spécialisation**:
*Bénédictain*:

*Pélérin*:

---
2. **Prière sacrée** – Tous les alliés dans la zone bénéficient d’un bonus temporaire.
3. **Arme bénie** – Enchante une arme pour infliger des dégâts sacrés
4. **Aura de courage** – Immunise les alliés proches contre la peur.
5. **Aura de protection** – Réduit les dégâts subis par les alliés proches.
6. **Résistance divine** – Accorde un bonus de résistance à un type 
7. **Soin modéré** – Guérit des blessures moyennes.
8. **Soin majeur** – Rétablit de lourds dommages.
9. **Soin de groupe** – Soigne tous les alliés proches.
10. **Guérison suprême** – Restaure presque tous les PV d’un allié.
11. **Restauration complète** – Supprime toutes les altérations majeures.
**Délivrance des maladies** – Élimine les maladies naturelles ou magiques.
12. **Rappel à la vie** – Ramène un mort récent à la vie avec un faible total de PV.

---

### ⚖️ **Jugement & Châtiment Divin**

21. **Jugement sacré** – Inflige des dégâts à un ennemi jugé impur.
22. **Flamme divine** – Projette un feu sacré sur un ennemi.
23. **Rayon de châtiment** – Tire un rayon concentré d’énergie divine.
24. **Chaine céleste** – Immobilise un ennemi avec des chaînes de lumière.
25. **Marque du pécheur** – Marque un ennemi, rendant ses attaques moins efficaces.
26. **Boulon de lumière** – Lance un éclair de lumière pure infligeant des dégâts radiants.
27. **Courroux céleste** – Provoque une explosion de lumière infligeant des dégâts de zone.
28. **Expulsion des morts-vivants** – Repousse ou détruit les morts-vivants proches.
29. **Fureur de l’au-delà** – Invoque un bref assaut d’âmes vengeresses.
30. **Châtiment des impurs** – Frappe sévèrement une créature mauvaise.

---

### ☠️ **Malédictions & Pénalités**

31. **Malédiction de faiblesse** – Réduit la force physique d’un ennemi.
32. **Lenteur divine** – Ralentit les mouvements et les réactions d’un ennemi.
33. **Cécité sacrée** – Rend un ennemi aveugle pendant un certain temps.
34. **Sceau du silence** – Empêche un ennemi de lancer des sorts verbaux.
35. **Interdiction** – Interdit magiquement à un ennemi d’entrer dans une zone sacrée.
36. **Suppression de magie** – Dissipe un effet magique actif.
37. **Bannissement** – Envoie une créature extraplanaire dans son plan d’origine.
38. **Faim spirituelle** – Inflige des dégâts mentaux en affamant l’âme.
39. **Tourment de l’âme** – Inflige une douleur morale intense à une cible.
40. **Poids de la foi** – Ralentit et oppresse un être impur.

---

### 🧠 **Contrôle Mental & Spirituel**

41. **Calme émotionnel** – Apaise les émotions fortes dans une zone.
42. **Dissuasion divine** – Force les ennemis à éviter l’attaque ou la violence.
43. **Vérité sacrée** – Contraint une créature à dire la vérité.
44. **Silence sacré** – Crée une zone où aucun son ne peut être émis.
45. **Protection contre l’influence mentale** – Immunise une cible contre le contrôle mental.
46. **Purification de l’esprit** – Supprime les effets de confusion ou d’envoûtement.
47. **Domination pieuse** – Prend brièvement le contrôle d’une créature faible.
48. **Bouclier mental** – Empêche les intrusions psychiques.
49. **Communion divine** – Permet au clerc de poser des questions à sa divinité.
50. **Supplication céleste** – Imploration d’un effet mineur auprès de son dieu.

---

### 🕊️ **Défenses & Boucliers**

51. **Mur de lumière** – Crée un mur impénétrable de lumière.
52. **Sanctuaire** – Les ennemis hésitent à attaquer la cible.
53. **Immunité sacrée** – Rend temporairement une créature invulnérable à un effet.
54. **Armure divine** – Crée une armure magique autour de la cible.
55. **Cercle de foi** – Zone de protection contre les créatures maléfiques.
56. **Résilience sacrée** – Réduit de moitié les dégâts subis.
57. **Dissipation du mal** – Supprime les enchantements maléfiques.
58. **Réflexe béni** – Donne une chance d’éviter complètement une attaque.
59. **Barrière angélique** – Invoque des ailes protectrices autour d’un allié.
60. **Bénédiction d’endurance** – Augmente temporairement les points de vie.

---

### 🔍 **Détection & Divination**

61. **Détection du mal** – Indique la présence de créatures ou objets maléfiques.
62. **Détection de la magie** – Révèle les auras magiques dans une zone.
63. **Détection de la vie** – Indique où se trouvent les êtres vivants.
64. **Vision sacrée** – Permet de voir dans l’obscurité magique.
65. **Clairvoyance divine** – Permet de voir à distance dans un lieu sacré.
66. **Lecture des intentions** – Perçoit les intentions immédiates d’un individu.
67. **Présence divine** – Sent la proximité d’une entité divine.
68. **Communion avec le dieu** – Obtiens une réponse à une question complexe.
69. **Révélation des péchés** – Voit les actes mauvais passés d’un être.
70. **Œil céleste** – Crée un œil magique flottant qui observe pour le clerc.

---

### 🕯️ **Rituels & Miracles**

71. **Résurrection** – Ramène à la vie un mort avec ses souvenirs.
72. **Miracle** – Invoque un effet quasi illimité selon la volonté divine.
73. **Sanctification d’un lieu** – Rend une zone sacrée.
74. **Création d’eau sacrée** – Produit de l’eau bénite.
75. **Bénédiction des récoltes** – Garantit une saison prospère.
76. **Chasse aux esprits** – Force les esprits à fuir ou se manifester.
77. **Prière du crépuscule** – Augmente la régénération des alliés pendant la nuit.
78. **Consécration d’objet** – Transforme un objet en artefact béni.
79. **Exorcisme** – Expulse un esprit possédant un hôte.
80. **Invocation céleste** – Invoque un messager divin pour une tâche.

---

### 🌠 **Effets Utilitaires**

81. **Création de nourriture** – Nourrit un groupe pendant un jour.
82. **Lévitation divine** – Soulève une cible sans effort.
83. **Marche sur l’eau** – Permet de traverser les surfaces liquides.
84. **Réduction de la douleur** – Apaise instantanément une souffrance physique.
85. **Parole universelle** – Permet de parler et comprendre toutes les langues.
86. **Sceau lumineux** – Appose un sceau visible uniquement par les clercs.
87. **Lumière éternelle** – Crée une source de lumière permanente.
88. **Apaisement des craintes** – Supprime l’état de peur chez les alliés.
89. **Dissipation de l’obscurité** – Dissipe les ténèbres magiques ou naturelles.
90. **Empreinte sacrée** – Laisse une marque bénie que seul le clerc peut suivre.

---

### ⚔️ **Capacités de Combat & Soutien**

91. **Renforcement d’arme alliée** – Accroît les dégâts d’un allié pendant un combat.
92. **Sacrifice vital** – Le clerc prend les blessures d’un allié sur lui-même.
93. **Frappe purificatrice** – Une attaque qui dissipe les effets néfastes d’un ennemi.
94. **Transfert de vie** – Donne ses PV à une autre créature.
95. **Poussée divine** – Repousse une cible avec une force sacrée.
96. **Appel des protecteurs** – Invoque des esprits pour défendre un allié.
97. **Ancre de foi** – Immobilise un ennemi tant qu’il regarde le clerc.
98. **Souffle sanctifié** – Libère un cône d’énergie positive.
99. **Emprise du serment** – Rend un ennemi incapable de rompre un engagement.
100. **Résurgence céleste** – Rend tous les alliés debout avec quelques PV.

---

Souhaites-tu maintenant une **version plus longue et détaillée** (portée, durée, composantes, niveau, etc.) pour certains de ces sorts ? Je peux aussi t'aider à les intégrer à un système de jeu.
